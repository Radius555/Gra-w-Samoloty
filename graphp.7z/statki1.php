<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="css.css" type="text/css">
</head>
<body>
<div id="calosc">
<div id="gora">
<h1> Hello </h1>
</div>
<div id="menu">
<p> Menu gry </p>
<br><br>
<a href="html1.html"><p> Aby wrócić do strony głównej pliknik tu :) </p></a>
</div>
<div id="gra1">
<div id="gra1madzy">
<div id="pytania">
<div id="pytanka">
<!--<?php
	/*$pol = mysqli_connect('localhost', 'root', '','pytanka1');
	$dane = mysqli_query($pol,"SELECT * FROM dywizja 303 WHERE id=1"); 
	
	while ($ele = $mysqli_fetch_array($dane))
	{
	echo $pytanie = $ele['Pytanie']." ".$OdpA = $ele['OdpA']." ".$OdpB = $ele['OdpB']." ".$OdpC = $ele['OdpC']." ".$OdpD = $ele['OdpD']." ".$OdpP = $ele['Poprawna'];
	}
	mysqli_close($polacz);*/
?>-->
<form method="POST" action="statki1.php">
<input type="button" name="Pytanie"/><br>
<input type="button" name="OdpA"  onclick="function sprawdz(odpA)"/><br>
<input type="button" name="OdpB" onclick="function sprawdz(odpB)"/><br>
<input type="button" name="OdpC" onclick="function sprawdz(odpC)" /><br>
<input type="button" name="OdpD" onclick="function sprawdz(odpD)"/><br>
</form>
</div>
<br>
<div id="pyt">
<b>Pytania</b>
</div>
<br><br>
<table id="tabelka" align="left">
<script src="skrypt.js"></script>
<tr>
 <td class="inny_wyglad1"></td>
 <td class="inny_wyglad1">A</td>
 <td class="inny_wyglad1">B</td>
 <td class="inny_wyglad1">C</td>
 <td class="inny_wyglad1">D</td>
 <td class="inny_wyglad1">E</td> 
 <td class="inny_wyglad1">F</td>
 <td class="inny_wyglad1">G</td>
 <td class="inny_wyglad1">H</td>
</tr>
<tr>
 <td class="inny_wyglad2" >1</td>
 <td onClick="odp1(65)"> <img src="pytanie.png" alt="nic"id="65"></td>
 <td onClick="odp1(66)"> <img src="pytanie.png" alt="nic"id="66"></td>
 <td onClick="odp1(67)"> <img src="pytanie.png" alt="nic"id="67"></td>
 <td onClick="odp1(68)"> <img src="pytanie.png" alt="nic"id="68"></td>
 <td onClick="odp1(69)"> <img src="pytanie.png" alt="nic"id="69"></td>
 <td onClick="odp1(70)"> <img src="pytanie.png" alt="nic" id="70"></td>
 <td onClick="odp1(71)"> <img src="pytanie.png" alt="nic" id="71"></td>
 <td class="inny_wyglad4" onClick="odp1(72)"> <img src="pytanie.png" alt="nic" id="72"></td>
</tr>
<tr>
 <td class="inny_wyglad2">2</td>
 <td onClick="odp1(73)"> <img src="pytanie.png" alt="nic" id="73"></td>
 <td onClick="odp1(74)"> <img src="pytanie.png" alt="nic" id="74"></td>
 <td onClick="odp1(75)"> <img src="pytanie.png" alt="nic" id="75"></td>
 <td onClick="odp1(76)"> <img src="pytanie.png" alt="nic" id="76"></td>
 <td onClick="odp1(77)"> <img src="pytanie.png" alt="nic" id="77"></td>
 <td onClick="odp1(78)"> <img src="pytanie.png" alt="nic" id="78"></td>
 <td onClick="odp1(79)"> <img src="pytanie.png" alt="nic" id="79"></td>
 <td class="inny_wyglad4" onClick="odp1(80)"> <img src="pytanie.png" alt="nic" id="80"></td>
</tr>
<tr>
 <td class="inny_wyglad2">3</td>
 <td onClick="odp2(81)"> <img src="pytanie.png" alt="nic" id="81"></td>
 <td onClick="odp2(82)"> <img src="pytanie.png" alt="nic" id="82"></td>
 <td onClick="odp2(83)"> <img src="pytanie.png" alt="nic" id="83"></td>
 <td onClick="odp2(84)"> <img src="pytanie.png" alt="nic" id="84"></td>
 <td onClick="odp2(85)"> <img src="pytanie.png" alt="nic" id="85"></td>
 <td onClick="odp2(86)"> <img src="pytanie.png" alt="nic" id="86"></td>
 <td onClick="odp2(87)"> <img src="pytanie.png" alt="nic" id="87"></td>
 <td class="inny_wyglad4" onClick="odp2(88)"> <img src="pytanie.png" alt="nic" id="88"></td>
</tr>
<tr>
 <td class="inny_wyglad2">4</td>
 <td onClick="odp2(89)"> <img src="pytanie.png" alt="nic" id="89"></td>
 <td onClick="odp2(90)"> <img src="pytanie.png" alt="nic" id="90"></td>
 <td onClick="odp2(91)"> <img src="pytanie.png" alt="nic" id="91"></td>
 <td onClick="odp2(92)"> <img src="pytanie.png" alt="nic" id="92"></td>
 <td onClick="odp2(93)"> <img src="pytanie.png" alt="nic" id="93"></td>
 <td onClick="odp2(94)"> <img src="pytanie.png" alt="nic" id="94"></td>
 <td onClick="odp2(95)"> <img src="pytanie.png" alt="nic" id="95"></td>
 <td class="inny_wyglad4" onClick="odp2(96)"> <img src="pytanie.png" alt="nic" id="96"></td>
</tr>
<tr>
 <td class="inny_wyglad2">5</td>
 <td onClick="odp3(97)"> <img src="pytanie.png" alt="nic" id="97"></td>
 <td onClick="odp3(98)"> <img src="pytanie.png" alt="nic" id="98"></td>
 <td onClick="odp3(99)"> <img src="pytanie.png" alt="nic" id="99"></td>
 <td onClick="odp3(100)"> <img src="pytanie.png" alt="nic" id="100"></td>
 <td onClick="odp3(101)"> <img src="pytanie.png" alt="nic" id="101"></td>
 <td onClick="odp3(102)"> <img src="pytanie.png" alt="nic" id="102"></td>
 <td onClick="odp3(103)"> <img src="pytanie.png" alt="nic" id="103"></td>
 <td class="inny_wyglad4" onClick="odp3(104)"> <img src="pytanie.png" alt="nic" id="104"></td>
</tr> 
<tr>
 <td class="inny_wyglad2">6</td>
 <td onClick="odp3(105)"> <img src="pytanie.png" alt="nic" id="105"></td>
 <td onClick="odp3(106)"> <img src="pytanie.png" alt="nic" id="106"></td>
 <td onClick="odp3(107)"> <img src="pytanie.png" alt="nic" id="107"></td>
 <td onClick="odp3(108)"> <img src="pytanie.png" alt="nic" id="108"></td>
 <td onClick="odp3(109)"> <img src="pytanie.png" alt="nic" id="109"></td>
 <td onClick="odp3(110)"> <img src="pytanie.png" alt="nic" id="110"></td>
 <td onClick="odp3(111)"> <img src="pytanie.png" alt="nic" id="111"></td>
 <td class="inny_wyglad4" onClick="odp3(112)"> <img src="pytanie.png" alt="nic" id="112"></td>
</tr>
<tr>
 <td class="inny_wyglad2">7</td>
 <td onClick="odp4(113)"> <img src="pytanie.png" alt="nic" id="113"></td>
 <td onClick="odp4(114)"> <img src="pytanie.png" alt="nic" id="114"></td>
 <td onClick="odp4(115)"> <img src="pytanie.png" alt="nic" id="115"></td>
 <td onClick="odp4(116)"> <img src="pytanie.png" alt="nic" id="116"></td>
 <td onClick="odp4(117)"> <img src="pytanie.png" alt="nic" id="117"></td>
 <td onClick="odp4(118)"> <img src="pytanie.png" alt="nic" id="118"></td>
 <td onClick="odp4(119)"> <img src="pytanie.png" alt="nic" id="119"></td>
 <td class="inny_wyglad4" onClick="odp4(120)"> <img src="pytanie.png" alt="nic" id="120"></td>
</tr>
<tr>
 <td class="inny_wyglad2">8</td>
 <td onClick="odp4(121)"> <img src="pytanie.png" alt="nic" id="121"></td>
 <td onClick="odp4(122)"> <img src="pytanie.png" alt="nic" id="122"></td>
 <td onClick="odp4(123)"> <img src="pytanie.png" alt="nic" id="123"></td>
 <td onClick="odp4(124)"> <img src="pytanie.png" alt="nic" id="124"></td>
 <td onClick="odp4(125)"> <img src="pytanie.png" alt="nic" id="125"></td>
 <td onClick="odp4(126)"> <img src="pytanie.png" alt="nic" id="126"></td>
 <td onClick="odp4(127)"> <img src="pytanie.png" alt="nic" id="127"></td>
 <td class="inny_wyglad4" onClick="odp4(128)"> <img src="pytanie.png" alt="nic" id="128"></td>
</tr>
</table>
<table id="tabelka2">
<tr><th>
<b>KATEGORIA</b>
</th></tr>
<tr><td>
<br><br><b>Dywizja 303</b>
</td></tr>
<tr><td>
<br><br><b>Bitwa o Anglie</b>
</td></tr>
<tr><td>
<br><br><b>Polacy w Bitwie o Anglie</b>
</td></tr>
<tr><td>
<br><br><b>Statystyka</b>
</td></tr>
</table>
<table id="tabelka3">
<tr><th>PUNKTACJA <br>INDYWIDUALNA</th></tr>
<tr><td><b>IMIĘ 1</b></td>
<td class="inny_wyglad">PTS</td></tr>
<tr><td><b>IMIĘ 2</b></td>
<td class="inny_wyglad">PTS</td></tr>
<tr><td><b>IMIĘ 3</b></td>
<td class="inny_wyglad">PTS</td></tr>
<tr><td><b>IMIĘ 4</b></td>
<td class="inny_wyglad">PTS</td></tr>
</table>
<div id="blok">
<div id="wynik0"><b>Wynik Meczu </b></div>
<div id="madzy">Drużyna Magów</div>
<div id="czarni">Drużyna Czarnoksiężnika</div>
<div id="wynik1"></div>
<div id="wynik2"></div>
</div>
</div>
<div id="drzewa">
<br>
<!-- <div id="mag">
<b>Drużyna Magów</b>
</div> ----> 
<table id="tabla" align="left">
<script src="skrypt.js"></script>
<tr>
 <td class="inny_td"></td>
 <td class="inny_td">A</td>
 <td class="inny_td">B</td>
 <td class="inny_td">C</td>
 <td class="inny_td">D</td>
 <td class="inny_td">E</td>
 <td class="inny_td">F</td>
 <td class="inny_td">G</td>
 <td class="inny_td">H</td>
</tr>
<tr>
 <td class="inny_td">1</td>
 <td onClick="zmien(1)"> <img src="Chmurka.png" alt="jedyneczka" id="1"></td>
 <td onClick="zmien(2)"> <img src="Chmurka.png" alt="jedyneczka" id="2"></td>
 <td onClick="zmien(3)" > <img src="Chmurka.png" alt="jedyneczka" id="3"></td>
 <td onClick="zmien(4)" > <img src="Chmurka.png" alt="jedyneczka" id="4"></td>
 <td onClick="zmien(5)" > <img src="Chmurka.png" alt="jedyneczka" id="5"></td>
 <td onClick="zmien(6)" > <img src="Chmurka.png" alt="jedyneczka" id="6"></td>
 <td onClick="zmien(7)" > <img src="Chmurka.png" alt="jedyneczka" id="7"></td>
 <td onClick="zmien(8)" > <img src="Chmurka.png" alt="jedyneczka" id="8"></td>
</tr>
<tr>
 <td class="inny_td">2</td>
 <td onClick="zmien(9)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="9"></td>
 <td onClick="zmien(10)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="10"></td>
 <td onClick="zmien(11)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="11"></td>
 <td onClick="zmien(12)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="12"></td>
 <td onClick="zmien(13)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="13"></td>
 <td onClick="zmien(14)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="14"></td>
 <td onClick="zmien(15)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="15"></td>
 <td onClick="zmien(16)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="16"></td>
</tr>
<tr>
 <td class="inny_td">3</td>
 <td onClick="zmien(17)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="17"></td>
 <td onClick="zmien(18)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="18"></td>
 <td onClick="zmien(19)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="19"></td>
 <td onClick="zmien(20)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="20"></td>
 <td onClick="zmien(21)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="21"></td>
 <td onClick="zmien(22)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="22"></td>
 <td onClick="zmien(23)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="23"></td>
 <td onClick="zmien(24)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="24"></td>
</tr>
<tr>
 <td class="inny_td">4</td>
 <td onClick="zmien(25)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="25"></td>
 <td onClick="zmien(26)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="26"></td>
 <td onClick="zmien(27)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="27"></td>
 <td onClick="zmien(28)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="28"></td>
 <td onClick="zmien(29)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="29"></td>
 <td onClick="zmien(30)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="30"></td>
 <td onClick="zmien(31)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="31"></td>
 <td onClick="zmien(32)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="32"></td>
</tr>
<tr>
 <td class="inny_td">5</td>
 <td onClick="zmien(33)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="33"></td>
 <td onClick="zmien(34)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="34"></td>
 <td onClick="zmien(35)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="35"></td>
 <td onClick="zmien(36)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="36"></td>
 <td onClick="zmien(37)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="37"></td>
 <td onClick="zmien(38)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="38"></td>
 <td onClick="zmien(39)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="39"></td>
 <td onClick="zmien(40)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="40"></td>
</tr>
<tr>
 <td class="inny_td">6</td>
 <td onClick="zmien(41)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="41"></td>
 <td onClick="zmien(42)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="42"></td>
 <td onClick="zmien(43)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="43"></td>
 <td onClick="zmien(44)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="44"></td>
 <td onClick="zmien(45)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="45"></td>
 <td onClick="zmien(46)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="46"></td>
 <td onClick="zmien(47)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="47"></td>
 <td onClick="zmien(48)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="48"></td>
</tr>
<tr>
 <td class="inny_td">7</td>
 <td onClick="zmien(49)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="49"></td>
 <td onClick="zmien(50)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="50"></td>
 <td onClick="zmien(51)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="51"></td>
 <td onClick="zmien(52)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="52"></td>
 <td onClick="zmien(53)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="53"></td>
 <td onClick="zmien(54)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="54"></td>
 <td onClick="zmien(55)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="55"></td>
 <td onClick="zmien(56)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="56"></td>
</tr>
<tr>
 <td class="inny_td">8</td>
 <td onClick="zmien(57)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="57"></td>
 <td onClick="zmien(58)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="58"></td>
 <td onClick="zmien(59)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="59"></td>
 <td onClick="zmien(60)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="60"></td>
 <td onClick="zmien(61)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="61"></td>
 <td onClick="zmien(62)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="62"></td>
 <td onClick="zmien(63)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="63"></td>
 <td onClick="zmien(64)" > <img src="Chmurka.png" alt="kolko lub krzyzyk" id="64"></td>
</tr>
</table>
</div>
</div>
</div>
</div>
<div id="prawy1">
nic
</div>
<div id="dol">
<p>Dół</p>
</div>
<div id="stopka">
<p>DDDDDD</p>
</div>
</div>
</body>
</html>